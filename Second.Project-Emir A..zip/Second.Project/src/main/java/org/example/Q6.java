package org.example;

public class Q6 {

    //6. Create a method to count how many vowels are present in a string
    //“documentation”

    public static void main(String[] args) {

        String v="documentation";

        int vowelCount=0;

        for (int i = 0; i < v.length(); i++) {char c=v.charAt(i);
            if ("aeiou".indexOf(c)!=-1){
                vowelCount++;
            }

        }
        System.out.println(vowelCount+" vowels are present in a string.");






    }
}
