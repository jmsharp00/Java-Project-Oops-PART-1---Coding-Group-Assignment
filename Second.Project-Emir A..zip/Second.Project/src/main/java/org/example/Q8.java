package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Q8 {

    //8. You have a list of strings and you want to keep only those that start with
//“A” and you want to return them in lower case".
    public static void main(String[] args) {

        List<String> strings = Arrays.asList("Apple", "Banana", "Avocado", "Grape", "Apricot");



        List<String> result =new ArrayList<>();

        for (String str:strings){
            if (str.startsWith("A")){result.add(str.toLowerCase());
        }}


        System.out.println(result);
    }
}

