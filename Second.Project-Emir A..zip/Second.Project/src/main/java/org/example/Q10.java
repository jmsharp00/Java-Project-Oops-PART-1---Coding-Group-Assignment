package org.example;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.TreeSet;

public class Q10 {

    //How can you remove all duplicates from ArrayList?
    public static void main(String[] args) {

        ArrayList<String> countries=new ArrayList<>();

        countries.add("India");
        countries.add("India");
        countries.add("Australia");
        countries.add("South Africa");
        countries.add("India");
        countries.add("America");
        countries.add("America");


        HashSet<String> set=new HashSet<>(countries);
        countries.clear();
        countries.addAll(set);
        System.out.println(countries);

    }
}
