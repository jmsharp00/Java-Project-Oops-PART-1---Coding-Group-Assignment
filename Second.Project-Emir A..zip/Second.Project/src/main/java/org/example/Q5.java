package org.example;

public class Q5 {
    //5. Check if Two Strings are Anagrams: Given two strings, determine if they
    //are anagrams, meaning they contain the same characters in a different order.
    //For example, "listen" and "silent" are anagrams
    public static void main(String[] args) {

        String v1="listen";
        String v2="silent";

        if (sortString(v1).equals(sortString(v2))) {
            System.out.println(v1 + " and " + v2 + " are anagrams.");
        } else {
            System.out.println(v1 + " and " + v2 + " are not anagrams.");
        }
    }

    public static String sortString(String v) {
        char[]arr= v.toCharArray();
        java.util.Arrays.sort(arr);

        return new String(arr);

    }


}

