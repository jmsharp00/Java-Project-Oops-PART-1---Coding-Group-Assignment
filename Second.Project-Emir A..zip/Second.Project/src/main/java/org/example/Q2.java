package org.example;

public class Q2 {
    public static void main(String[] args) {


        //2. Find out how many alpha characters are present in a string?

        String v = "Hello World! 2024";

        int count = v.replaceAll("[^a-zA-Z]", "").length();

        System.out.println(count+" alpha characters are present in a string.");
    }
}
