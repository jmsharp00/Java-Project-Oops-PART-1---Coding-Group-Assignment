package org.example;

public class Q3 {
    public static void main(String[] args) {



    //3 Reverse a String: Write a function to reverse a given string. For example,
    //given the input "Hello", the output should be "olleH".


    String v="Hello";

    String reversed=new StringBuilder(v).reverse().toString();

        System.out.println(reversed);







}}
