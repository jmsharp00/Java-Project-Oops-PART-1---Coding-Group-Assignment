package org.example;

public class Q1 {
    public static void main(String[] args) {

        //1. Write a program to swap 2 String without a temporary variable?

        String firstV="Hello";
        String secondV="World";


        System.out.println("Before swap: ");
        System.out.println("firstV= "+firstV);
        System.out.println("secondV= "+secondV);

        firstV=firstV+secondV;
        secondV=firstV.substring(0,firstV.length()-secondV.length());
        firstV=firstV.substring(secondV.length());
        System.out.println();

        System.out.println("After swap: ");
        System.out.println("firstV= "+firstV);
        System.out.println("secondV= "+secondV);






    }
}
