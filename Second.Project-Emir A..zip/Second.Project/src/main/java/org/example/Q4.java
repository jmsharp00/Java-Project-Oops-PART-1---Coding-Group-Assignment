package org.example;

public class Q4 {

    //4. Check if a String is Palindrome: Determine whether a given string is a
    //palindrome, which means it reads the same forwards and backward. For
    //example, "madam" is a palindrome


    public static void main(String[] args) {

        String v="madam";

        if (v.equals(new StringBuilder(v).reverse().toString())){
            System.out.println(v+" is a palindrome.");
        }else {
            System.out.println(v+" is not a palindrome.");











    }
}}
