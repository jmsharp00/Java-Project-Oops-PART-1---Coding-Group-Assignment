package org.example;

public class Q9 {
    //9. Find the First Non-Repeating Character in a String: Given a string, find and
    //return the first non-repeating character. For example, in the string
    //"abracadabra", the first non-repeating character is 'c'.
    public static void main(String[] args) {

                String v = "abracadabra";
                System.out.println("First non-repeating character: " + findFirstNonRepeating(v));
            }


            public static char findFirstNonRepeating(String v) {
                for (int i = 0; i < v.length(); i++) {

                    if (v.indexOf(v.charAt(i)) == v.lastIndexOf(v.charAt(i))) {
                        return v.charAt(i);
                    }
                }
                return '\0';
            }
        }





