package ZooEcosystemSimulation;

public class RegistrationTest {
    public static void main(String[] args) {
        Registration reg = new Registration();


        reg.setEmail("user@yahoo.com");
        reg.setUserName("john_doe");
        reg.setPassword("password123");


        reg.displayRegistrationDetails();
    }
}

