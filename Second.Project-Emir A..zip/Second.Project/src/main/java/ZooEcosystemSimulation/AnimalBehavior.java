package ZooEcosystemSimulation;


public interface AnimalBehavior {
    void eat();

    void sleep();

    void makeSound();
}





