package ZooEcosystemSimulation;

public class Bird extends Animal {

    public Bird(String name, int age) {
        super(name, age);
    }


    public void eat() {
        System.out.println(name + " is pecking food.");
    }


    public void makeSound() {
        System.out.println(name + " chirps.");
    }


    public void displayInformation() {
        System.out.println("Bird Name: " + name + ", Age: " + age);
    }
}
