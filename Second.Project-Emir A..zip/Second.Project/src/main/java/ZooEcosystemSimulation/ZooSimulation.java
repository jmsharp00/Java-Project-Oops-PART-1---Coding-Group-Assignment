package ZooEcosystemSimulation;

public class ZooSimulation {
    public static void main(String[] args) {

        Animal lion = new Lion("Leo", 5);
        Animal elephant = new Elephant("Dumbo", 10);
        Animal parrot = new Parrot("Polly", 3);
        Animal eagle = new Eagle("Sky", 4);


        lion.eat();
        lion.makeSound();
        lion.displayInformation();

        elephant.eat();
        elephant.makeSound();
        elephant.displayInformation();

        parrot.eat();
        parrot.makeSound();
        parrot.displayInformation();

        eagle.eat();
        eagle.makeSound();
        eagle.displayInformation();


        lion.sleep();
        elephant.sleep();
        parrot.sleep();
        eagle.sleep();
    }
}

