package zooEcoSystem;

public interface AnimalBehavior {
    void eat();;
    void makeSound();
    void sleep();
}
