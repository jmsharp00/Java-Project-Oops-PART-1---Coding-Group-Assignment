package RegistrationEx;

public class UserTest {
    public static void main(String[] args) {
        Registration user1 = new Registration("smth@email.com","Julia Smith", "end" );
        user1.displayInfo();}

}
